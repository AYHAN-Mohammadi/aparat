<?php
error_reporting(0);
header('Content-type: application/json');
/**
** Ayhan Mohammadi
** php ~ API aparat
** aparat.com
** telegram: @ayhan_dev
** Clearing information is prohibited
**/
class dl_aparat {
    public function is_aparat_url($url){
		$link = parse_url($url);
		if(isset($link['host'])){
			if(strpos($link['host'], 'aparat.com') !== false and strpos($link['path'], '/v/') !== false)
				return true;
			else
				return false;
		}
		elseif(isset($link['path'])){
			if(strpos($link['path'], 'aparat.com/v/') !== false)
				return true;
			else
				return false;
		}
		return false;
	}
    
    public function getContents($url){
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36');
        return curl_exec($curl);
        curl_close($curl);
    }

    public function getVideo($url){
        if($this->is_aparat_url($url)){
    	    $data = $this->getContents($url);
	        preg_match('"<meta property=\"og:title\" content=\"(.*?)\"/>"si', $data, $title);
	        preg_match('"<span class=\"tooltip tooltip-dark tooltip-b tooltip-center tooltip-line tooltip-small\">دانلود ویدیو</span>
</div></div>
    <div class=\"dropdown-content\"><div  class=\"menu-wrapper\">
        <ul class=\"menu-list\">(.*)</ul>"si', $data, $link);
    	    preg_match_all('"<li class=\"menu-item-link link\">
                        <a  href=\"(.*?)\" target=\"_blank\""si', $link[1], $link);
	        preg_match('"<meta property=\"og:image\" content=\"(.*?)\"/>"si', $data, $poster);
	        preg_match('"<meta name=\"keywords\" content=\"(.*?)\"/>"si', $data, $keywords);
    	    $result = [];
	        $result['title'] = $title[1];
	        $result['poster'] = $poster[1];
	        if(!empty($keywords[1]))
		        $result['keywords'] = explode(',', $keywords[1]);
            $result['available'] = false;
    	    if(!empty($link[1])){
	    	    $result['available'] = true;
	    	    $qualities= ['144p', '240p', '360p', '480p', '720p', '1080p'];
		        for($i= 0; $i< count($link[1]); $i++){
		            foreach($qualities as $quality){
						if(strpos($link[1][$i], $quality) !== false){
			    	        $result['links'][$i]['quality'] = $quality;
				            $result['links'][$i]['link'] = $link[1][$i];
						}
		            }
    		    }
	    	    return $result;
	        } else
		        return false;
        } else
            return false;
    }
}


if(isset($_GET['link'])){
    $aparat= new dl_aparat;
    echo json_encode(['result'=> $aparat->getVideo($_GET['link'])], 448);
} else {
    echo json_encode(['message'=> 'link not set.'], 448);
} 
/**
** Ayhan Mohammadi
** php ~ API aparat
** aparat.com
** telegram: @ayhan_dev
** Clearing information is prohibited
**/ 
?>